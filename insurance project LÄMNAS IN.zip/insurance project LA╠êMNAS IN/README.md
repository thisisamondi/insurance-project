# Insurance Project

1. Forka detta repository
2. Klona ditt forkade repo så du får en lokal version
3. Kolla på pdf-filerna i mappen `mockup` för att se hur sidan ska se ut.
4. Öppna den klonade mappen i code and start codin'!
5. Gör commits ofta med tydliga commitmeddelanden
6. Pusha dina commits till github och verifiera att de finns uppe på github.com
